
# ATM Interface in C++

A basic ATM simulator made using C++.

## Features
- Check balance
- Deposit money
- Withdraw money

Simple menu-driven program.
