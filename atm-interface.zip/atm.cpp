
#include<iostream>
using namespace std;

float balance = 1000.00;

void showMenu() {
    cout << "\n1. Check Balance\n2. Deposit\n3. Withdraw\n4. Exit\n";
}

int main() {
    int choice;
    float amount;

    do {
        showMenu();
        cout << "Enter your choice: ";
        cin >> choice;

        switch(choice) {
            case 1:
                cout << "Balance: ₹" << balance << endl;
                break;
            case 2:
                cout << "Enter amount to deposit: ";
                cin >> amount;
                balance += amount;
                break;
            case 3:
                cout << "Enter amount to withdraw: ";
                cin >> amount;
                if(amount <= balance)
                    balance -= amount;
                else
                    cout << "Insufficient funds.\n";
                break;
            case 4:
                cout << "Thank you for using our ATM!\n";
                break;
            default:
                cout << "Invalid choice.\n";
        }
    } while(choice != 4);

    return 0;
}
